#include <stdio.h>
#include <string.h>

#define MAX 100

struct Product {
    int id;
    char name[50];
    float price;
    int quantity;
};

struct Product products[MAX];
int count = 0;

// Function Declarations
void addProduct();
void updateProduct();
void deleteProduct();
void displayProducts();
void searchByID();
void searchByName();
void quickSortByPrice(int low, int high);
void mergeSortByQuantity(int low, int high);

// Utility functions
void swap(struct Product *a, struct Product *b) {
    struct Product temp = *a;
    *a = *b;
    *b = temp;
}

// Partition function for QuickSort (by price)
int partition(int low, int high) {
    float pivot = products[high].price;
    int i = low - 1;
    for (int j = low; j < high; j++) {
        if (products[j].price <= pivot) {
            i++;
            swap(&products[i], &products[j]);
        }
    }
    swap(&products[i + 1], &products[high]);
    return i + 1;
}

// QuickSort for price
void quickSortByPrice(int low, int high) {
    if (low < high) {
        int pi = partition(low, high);
        quickSortByPrice(low, pi - 1);
        quickSortByPrice(pi + 1, high);
    }
}

// Merge function for MergeSort (by quantity)
void merge(int low, int mid, int high) {
    int n1 = mid - low + 1;
    int n2 = high - mid;

    struct Product L[n1], R[n2];

    for (int i = 0; i < n1; i++) L[i] = products[low + i];
    for (int j = 0; j < n2; j++) R[j] = products[mid + 1 + j];

    int i = 0, j = 0, k = low;
    while (i < n1 && j < n2) {
        if (L[i].quantity <= R[j].quantity)
            products[k++] = L[i++];
        else
            products[k++] = R[j++];
    }
    while (i < n1) products[k++] = L[i++];
    while (j < n2) products[k++] = R[j++];
}

// MergeSort for quantity
void mergeSortByQuantity(int low, int high) {
    if (low < high) {
        int mid = (low + high) / 2;
        mergeSortByQuantity(low, mid);
        mergeSortByQuantity(mid + 1, high);
        merge(low, mid, high);
    }
}

int main() {
    int choice;
    while (1) {
        printf("\n===== INVENTORY MANAGEMENT MENU =====\n");
        printf("1. Add Product\n");
        printf("2. Update Product\n");
        printf("3. Delete Product\n");
        printf("4. Display Products\n");
        printf("5. Search by ID\n");
        printf("6. Search by Name\n");
        printf("7. Sort by Price (QuickSort)\n");
        printf("8. Sort by Quantity (MergeSort)\n");
        printf("9. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: addProduct(); break;
            case 2: updateProduct(); break;
            case 3: deleteProduct(); break;
            case 4: displayProducts(); break;
            case 5: searchByID(); break;
            case 6: searchByName(); break;
            case 7: quickSortByPrice(0, count - 1); printf("Sorted by Price.\n"); break;
            case 8: mergeSortByQuantity(0, count - 1); printf("Sorted by Quantity.\n"); break;
            case 9: return 0;
            default: printf("Invalid choice!\n");
        }
    }
}

void addProduct() {
    if (count >= MAX) {
        printf("Inventory full! Cannot add more products.\n");
        return;
    }
    struct Product p;
    printf("Enter Product ID: ");
    scanf("%d", &p.id);
    getchar();
    printf("Enter Product Name: ");
    fgets(p.name, sizeof(p.name), stdin);
    p.name[strcspn(p.name, "\n")] = 0;
    printf("Enter Price: ");
    scanf("%f", &p.price);
    printf("Enter Quantity: ");
    scanf("%d", &p.quantity);

    products[count++] = p;
    printf("Product added successfully!\n");
}

void updateProduct() {
    int id;
    printf("Enter Product ID to update: ");
    scanf("%d", &id);
    for (int i = 0; i < count; i++) {
        if (products[i].id == id) {
            printf("Enter new Name: ");
            getchar();
            fgets(products[i].name, sizeof(products[i].name), stdin);
            products[i].name[strcspn(products[i].name, "\n")] = 0;
            printf("Enter new Price: ");
            scanf("%f", &products[i].price);
            printf("Enter new Quantity: ");
            scanf("%d", &products[i].quantity);
            printf("Product updated successfully!\n");
            return;
        }
    }
    printf("Product with ID %d not found.\n", id);
}

void deleteProduct() {
    int id;
    printf("Enter Product ID to delete: ");
    scanf("%d", &id);
    for (int i = 0; i < count; i++) {
        if (products[i].id == id) {
            for (int j = i; j < count - 1; j++) {
                products[j] = products[j + 1];
            }
            count--;
            printf("Product deleted successfully!\n");
            return;
        }
    }
    printf("Product with ID %d not found.\n", id);
}

void displayProducts() {
    if (count == 0) {
        printf("No products in inventory.\n");
        return;
    }
    printf("\n%-5s %-20s %-10s %-10s\n", "ID", "Name", "Price", "Quantity");
    printf("----------------------------------------------------\n");
    for (int i = 0; i < count; i++) {
        printf("%-5d %-20s %-10.2f %-10d\n", products[i].id, products[i].name, products[i].price, products[i].quantity);
    }
}

void searchByID() {
    int id;
    printf("Enter Product ID to search: ");
    scanf("%d", &id);
    for (int i = 0; i < count; i++) {
        if (products[i].id == id) {
            printf("Found: %d | %s | %.2f | %d\n", products[i].id, products[i].name, products[i].price, products[i].quantity);
            return;
        }
    }
    printf("Product with ID %d not found.\n", id);
}

void searchByName() {
    char search[50];
    getchar();
    printf("Enter Product Name to search: ");
    fgets(search, sizeof(search), stdin);
    search[strcspn(search, "\n")] = 0;
    for (int i = 0; i < count; i++) {
        if (strcmp(products[i].name, search) == 0) {
            printf("Found: %d | %s | %.2f | %d\n", products[i].id, products[i].name, products[i].price, products[i].quantity);
            return;
        }
    }
    printf("Product '%s' not found.\n", search);
}
